#include <stdio.h>

int main(void)
{
  int num_1=10, num_2, sum;
  num_2 = 20;
  sum=num_1 +num_2;
  num_1 = 25;
  num_2 = 50;
 sum = num_1 + num_2;
printf("Num 1 =%d\nNum 2 = %d\n", num_1, num_2);
printf("Sum = %d\n\n\n", sum);

  return 0;
}