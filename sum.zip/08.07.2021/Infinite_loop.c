#include<stdio.h>
int main(void)
{
  int count;
  while(count<100)
  {
    printf("%d ", count);
    count++;
  }
}